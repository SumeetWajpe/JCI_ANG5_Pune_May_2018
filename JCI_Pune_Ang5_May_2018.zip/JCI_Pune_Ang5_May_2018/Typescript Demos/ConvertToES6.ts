let aVar:string = "Hello !";

function Test(x:any,y:any){

}