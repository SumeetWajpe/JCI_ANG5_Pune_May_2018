var str = "Hello World !"; // Type inference !
//str = 100;  // Error !
console.log(str);

var x:number; // Type annotation !
x = 100;
var strVar:string;
var boolVar:boolean;
let anyVar:any;
anyVar = 100;
anyVar = "Bye !";
anyVar = {Name:'Angular'};
anyVar = ["Node"];

if(true){
    let blockScopedVar =100;
    // let blockScopedVar = 200;
    
    if(true){
        console.log(blockScopedVar);
    }
}

// const

const PI = 3.14;
// PI = 3.14576; // Error !

// functions
function Addition(x:number,y:number):number|string{
        return x + y;
}

let result:number|string = Addition(10,20);

// Arrays

let cars:string[] = ["BMW","AUDI","FERARRI"];
let moreCars:Array<string> = new Array<string>("TATA","MAHINDRA");


// for
// for-in
// for-of

for(let c of cars){
    console.log(c);
}


// functions -> Arrow Functions


// function Square(x){
//         return x * x;
// }

// functions as expression

// var Square = function(x){
//     return x*x;
// }

var Square = x => x * x;

function Emp(){
    this.Salary = 20000;   
    setTimeout((x)=>{
        console.log(this.Salary);
    },2000);
}

// Default, Optional, Rest Parameters

// function PrintBooks(author:string,noOfPages:number,title?:string){

//     title = title || "Unknown";
//     console.log(author,noOfPages,title);
// }


// function PrintBooks(author:string,noOfPages:number,title:string="Unknown"){

//     console.log(author,noOfPages,title);
// }

// PrintBooks("Dr. APJ Abdul Kalam",800,"Wings Of Fire");
// PrintBooks("Sachin Tendulkar",900);

function PrintBooks(author:string,...allTitles:string[]){
    console.log(author,allTitles);
}

PrintBooks("Sachin","Playing It My Way");
PrintBooks("Unknown Author !");
PrintBooks("Dr. APJ Abdul Kalam","Wings Of Fire","India 2020");


var allCars = [...cars,...moreCars]; // Spread 

interface ICompany{
    name:string;
    location:string;
    isMNC?:boolean;
    getDetails():void;
}

// Literal Syntax
var obj:ICompany = {name:'Accenture',location:'Pune',
getDetails:function(){

}
};

// Classes

class Car{
    private id:number;
    public name:string;
    speed:number;
    constructor(theId:number=0,theName:string="",theSpeed:number=0){
        this.id = theId;
        this.name = theName;
        this.speed = theSpeed;
    }
    Accelerate():string{
        // console.log(this.name + " is running at " + this.speed + " kmph !")

        return (`${this.name} is running at ${this.speed} kmph !`)
    }
}

// let carObj = new Car(1,"i20",200);
// carObj.Accelerate();

// var str = `kdsjhfdhf
// jdshfjfhdhf
// dkfjkdjfjkf
// dfdfjjjdhf
// `

class JamesBondCar extends Car{

    canFly:boolean;
    beInvisible:boolean;
    constructor(theId:number,theName:string,theSpeed:number,canItFly:boolean,beInvisible:boolean){
        super(theId,theName,theSpeed);
        this.canFly = canItFly;
        this.beInvisible = beInvisible;
    }

    Accelerate():string{
        return super.Accelerate() + " Can It Fly ? " + this.canFly;
    }

}
var jbcObj = new JamesBondCar(7,"Houston",400,true,true);
console.log(jbcObj.Accelerate());

interface IPerson{
    name:string;
    age:number;
}

interface iEmployee{
    email:string;
}

class Person implements IPerson,iEmployee{
    name:string;
    age:number;
    email:string;
}

// enhanced class syntax

class EnhancedCar{
    
    constructor(public name:string,public speed:number){

    }

}

var objECar = new EnhancedCar("i20",200);



