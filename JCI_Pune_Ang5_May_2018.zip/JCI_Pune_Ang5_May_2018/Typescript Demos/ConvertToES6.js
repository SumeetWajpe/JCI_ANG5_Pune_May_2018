let aVar = "Hello !";
function Test(x, y) {
}
