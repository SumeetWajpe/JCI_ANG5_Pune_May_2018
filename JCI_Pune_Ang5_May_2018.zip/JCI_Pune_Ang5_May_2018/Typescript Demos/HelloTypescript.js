var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var str = "Hello World !"; // Type inference !
//str = 100;  // Error !
console.log(str);
var x; // Type annotation !
x = 100;
var strVar;
var boolVar;
var anyVar;
anyVar = 100;
anyVar = "Bye !";
anyVar = { Name: 'Angular' };
anyVar = ["Node"];
if (true) {
    var blockScopedVar = 100;
    // let blockScopedVar = 200;
    if (true) {
        console.log(blockScopedVar);
    }
}
// const
var PI = 3.14;
// PI = 3.14576; // Error !
// functions
function Addition(x, y) {
    return x + y;
}
var result = Addition(10, 20);
// Arrays
var cars = ["BMW", "AUDI", "FERARRI"];
var moreCars = new Array("TATA", "MAHINDRA");
// for
// for-in
// for-of
for (var _i = 0, cars_1 = cars; _i < cars_1.length; _i++) {
    var c = cars_1[_i];
    console.log(c);
}
// functions -> Arrow Functions
// function Square(x){
//         return x * x;
// }
// functions as expression
// var Square = function(x){
//     return x*x;
// }
var Square = function (x) { return x * x; };
function Emp() {
    var _this = this;
    this.Salary = 20000;
    setTimeout(function (x) {
        console.log(_this.Salary);
    }, 2000);
}
// Default, Optional, Rest Parameters
// function PrintBooks(author:string,noOfPages:number,title?:string){
//     title = title || "Unknown";
//     console.log(author,noOfPages,title);
// }
// function PrintBooks(author:string,noOfPages:number,title:string="Unknown"){
//     console.log(author,noOfPages,title);
// }
// PrintBooks("Dr. APJ Abdul Kalam",800,"Wings Of Fire");
// PrintBooks("Sachin Tendulkar",900);
function PrintBooks(author) {
    var allTitles = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        allTitles[_i - 1] = arguments[_i];
    }
    console.log(author, allTitles);
}
PrintBooks("Sachin", "Playing It My Way");
PrintBooks("Unknown Author !");
PrintBooks("Dr. APJ Abdul Kalam", "Wings Of Fire", "India 2020");
var allCars = cars.concat(moreCars); // Spread 
// Literal Syntax
var obj = { name: 'Accenture', location: 'Pune',
    getDetails: function () {
    }
};
// Classes
var Car = /** @class */ (function () {
    function Car(theId, theName, theSpeed) {
        if (theId === void 0) { theId = 0; }
        if (theName === void 0) { theName = ""; }
        if (theSpeed === void 0) { theSpeed = 0; }
        this.id = theId;
        this.name = theName;
        this.speed = theSpeed;
    }
    Car.prototype.Accelerate = function () {
        // console.log(this.name + " is running at " + this.speed + " kmph !")
        return (this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
// let carObj = new Car(1,"i20",200);
// carObj.Accelerate();
// var str = `kdsjhfdhf
// jdshfjfhdhf
// dkfjkdjfjkf
// dfdfjjjdhf
// `
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(theId, theName, theSpeed, canItFly, beInvisible) {
        var _this = _super.call(this, theId, theName, theSpeed) || this;
        _this.canFly = canItFly;
        _this.beInvisible = beInvisible;
        return _this;
    }
    JamesBondCar.prototype.Accelerate = function () {
        return _super.prototype.Accelerate.call(this) + " Can It Fly ? " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbcObj = new JamesBondCar(7, "Houston", 400, true, true);
console.log(jbcObj.Accelerate());
var Person = /** @class */ (function () {
    function Person() {
    }
    return Person;
}());
// enhanced class syntax
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(name, speed) {
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());
var objECar = new EnhancedCar("i20", 200);
