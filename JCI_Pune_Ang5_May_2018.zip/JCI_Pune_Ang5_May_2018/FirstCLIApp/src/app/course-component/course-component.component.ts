import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import {buffer} from 'rxjs/operators';


@Component({
  selector: 'app-course-component',
  templateUrl: './course-component.component.html',
  styleUrls: ['./course-component.component.css']
})
export class CourseComponentComponent implements OnInit {


  courses:string[] = ['React','Node','Angular'];

  constructor() { 

  }

  ngOnInit() {
  }

}
