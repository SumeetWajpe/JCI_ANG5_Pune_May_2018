"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var posts_service_1 = require("./posts.service");
var PostsComponent = (function () {
    function PostsComponent(servObj) {
        var _this = this;
        this.servObj = servObj;
        // constructor(private servObj:PostsService){
        //  this.servObj.getPosts(function(respFromService:any){        
        //     console.log('Within Component !');
        //     console.log(respFromService)
        //  });
        // }
        this.allPosts = [];
        var aPromise = this.servObj.getPosts();
        aPromise.then(function (responseFromService) {
            console.log('Promise resolved !');
            _this.allPosts = responseFromService.json();
            localStorage['posts'] = JSON.stringify(_this.allPosts);
        }, function (err) {
            console.log('Promise rejected !');
            console.log(err);
        });
    }
    return PostsComponent;
}());
PostsComponent = __decorate([
    core_1.Component({
        selector: "posts",
        template: "\n\n        <h1> All Posts ! </h1>\n\n       \n\n        <ul >\n        <li *ngFor=\"let post of allPosts\" poststyle postColor=\"lightblue\" >\n        <a [routerLink]=\"['/post',post.id]\"> {{post.title}}  </a>\n        </li>\n        <ul>\n\n    ",
        providers: [posts_service_1.PostsService]
    }),
    __metadata("design:paramtypes", [posts_service_1.PostsService])
], PostsComponent);
exports.PostsComponent = PostsComponent;
//# sourceMappingURL=post.component.js.map