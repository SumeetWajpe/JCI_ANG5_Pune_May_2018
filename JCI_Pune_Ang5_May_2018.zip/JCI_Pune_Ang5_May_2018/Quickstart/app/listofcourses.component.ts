import { Component } from '@angular/core';


@Component({
  selector: 'list-of-courses',
template:`
 
<h1> List of Courses </h1>

<!-- <ul>
  <li *ngFor="let c of courses">{{c.name}}</li>
</ul> -->


<h1> Add a new Course </h1>

<form #f="ngForm" (ngSubmit)="HandleFormSubmit(f.form)">


  <div>
    <p *ngIf="f.valid" > The Form is Valid </p>
  </div>

    Name : <input type="text" name="cname"
     [(ngModel)]="newCourse.name" required class="form-control"/>
    Duration : <input type="text" name="cduration" 
    [(ngModel)]="newCourse.duration" class="form-control"/>
    Price : <input type="text" name="cprice" 
    [(ngModel)]="newCourse.price" class="form-control"/>
    Rating : <input type="text" name="crating"
     [(ngModel)]="newCourse.rating" class="form-control"/>
    
    <br/>
    <input type="submit" value="Add Course"
     class="btn btn-primary" [disabled]="!f.valid" />


</form>


<input type="text" [(ngModel)]="name" />

<ul [ngSwitch]="name">
  <li *ngSwitchCase="'Angular'">Angular</li>
  <li *ngSwitchCase="'React'">React</li>
  <li *ngSwitchCase="'Node'">Node</li>
  <li *ngSwitchDefault>No course with this name</li>
</ul>


<div>

</div>


<div *ngFor="let c of courses" [ngClass]="{'CourseStyle':true,'CourseBackground':true}">
  <course [coursedetails]="c"></course>
</div>

`
})
export class ListOfCoursesComponent  { 
  name = 'Angular';
  classToBeApplied:string= "CourseStyle";
  newCourse:any= {};
  courses=[
  {name:"Node",duration:3,price:3000,rating:3.7686,imageurl:`https://cdn-images-1.medium.com/max/960/1*pxfq-ikL8zPE3RyGB2xbng.png`},
  {name:"React",duration:2,price:4000,rating:5,imageurl:`https://cdn-images-1.medium.com/max/1468/1*kt9otqHk14BZIMNruiG0BA.png`},
  {name:"Angular",duration:5,price:5000,rating:3,imageurl:`https://d2eip9sf3oo6c2.cloudfront.net/tags/images/000/000/300/full/angular2.png`}
];

HandleFormSubmit(theForm:any){
  //??
  // update the collection -  courses

  let courseToBeAdded = {
    name:this.newCourse.name,
    duration:this.newCourse.duration,
    price:this.newCourse.price,
    rating:this.newCourse.rating,
    imageurl:'https://cdn-images-1.medium.com/max/1468/1*kt9otqHk14BZIMNruiG0BA.png'
  }


  if(theForm.valid){
  this.courses.push(courseToBeAdded);
      
  }

  // this.newCourse = {};
  theForm.reset();
}
  
 }
