import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {RouterModule,Routes} from '@angular/router';

import { AppComponent }  from './app.component';
import {CourseComponent} from './courses.component';
import { DurationPipe } from './duration.pipe';
import { UseCourseServComponent } from './usecourseservice';
import { CourseService } from './course.service';
import { PostsComponent } from './post.component';
import { ListOfCoursesComponent } from './listofcourses.component';
import { PostDetailComponent } from './postdetail.component';
import { LoginComponent } from './login.component';
import { DashBoardComponent } from './dashboard.component';
import { UserService } from './user.service';
import { AuthGaurd } from './authgaurd.service';
import { PostStyleDirective } from './poststyle.directive';

// const routes:Routes =[
// {path:'posts',component:PostsComponent},
// {path:'courses',component:ListOfCoursesComponent},
// {path:'post/:id',component:PostDetailComponent},
// {path:'',redirectTo:'/posts',pathMatch:'full'},
// {path:'**',redirectTo:'/courses',pathMatch:'full'}
// ]

const routes:Routes =[
  {
    path:'dashboard',
  component:DashBoardComponent,
  children:[
    {path:'',component:PostsComponent},
    {path:'courses',component:ListOfCoursesComponent}
  ]
  //,  canActivate:[AuthGaurd]
},
{path:'',component:LoginComponent}
]

@NgModule({
  imports:      [HttpModule, BrowserModule,
    FormsModule,RouterModule.forRoot(routes) ],
  declarations: [ PostStyleDirective, LoginComponent,DashBoardComponent, PostDetailComponent, AppComponent,CourseComponent,
   ListOfCoursesComponent, DurationPipe, PostsComponent, UseCourseServComponent ],
  bootstrap:    [ AppComponent ],
  providers:[CourseService,UserService,AuthGaurd]
})
export class AppModule { }
