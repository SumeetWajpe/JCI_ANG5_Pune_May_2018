import { Component } from '@angular/core';


@Component({
  selector: 'my-app',
  template:`
  <!--
  <h1> Using Routing </h1>
  
  <a routerLink="/posts" class="btn btn-primary" > Posts </a>
  <a routerLink="/courses" class="btn btn-primary" > Courses </a>
  
  -->

  <router-outlet></router-outlet>
`

})
export class AppComponent  { 
 
  
 }
