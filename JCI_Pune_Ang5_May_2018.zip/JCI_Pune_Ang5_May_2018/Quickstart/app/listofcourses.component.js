"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ListOfCoursesComponent = (function () {
    function ListOfCoursesComponent() {
        this.name = 'Angular';
        this.classToBeApplied = "CourseStyle";
        this.newCourse = {};
        this.courses = [
            { name: "Node", duration: 3, price: 3000, rating: 3.7686, imageurl: "https://cdn-images-1.medium.com/max/960/1*pxfq-ikL8zPE3RyGB2xbng.png" },
            { name: "React", duration: 2, price: 4000, rating: 5, imageurl: "https://cdn-images-1.medium.com/max/1468/1*kt9otqHk14BZIMNruiG0BA.png" },
            { name: "Angular", duration: 5, price: 5000, rating: 3, imageurl: "https://d2eip9sf3oo6c2.cloudfront.net/tags/images/000/000/300/full/angular2.png" }
        ];
    }
    ListOfCoursesComponent.prototype.HandleFormSubmit = function (theForm) {
        //??
        // update the collection -  courses
        var courseToBeAdded = {
            name: this.newCourse.name,
            duration: this.newCourse.duration,
            price: this.newCourse.price,
            rating: this.newCourse.rating,
            imageurl: 'https://cdn-images-1.medium.com/max/1468/1*kt9otqHk14BZIMNruiG0BA.png'
        };
        if (theForm.valid) {
            this.courses.push(courseToBeAdded);
        }
        // this.newCourse = {};
        theForm.reset();
    };
    return ListOfCoursesComponent;
}());
ListOfCoursesComponent = __decorate([
    core_1.Component({
        selector: 'list-of-courses',
        template: "\n \n<h1> List of Courses </h1>\n\n<!-- <ul>\n  <li *ngFor=\"let c of courses\">{{c.name}}</li>\n</ul> -->\n\n\n<h1> Add a new Course </h1>\n\n<form #f=\"ngForm\" (ngSubmit)=\"HandleFormSubmit(f.form)\">\n\n\n  <div>\n    <p *ngIf=\"f.valid\" > The Form is Valid </p>\n  </div>\n\n    Name : <input type=\"text\" name=\"cname\"\n     [(ngModel)]=\"newCourse.name\" required class=\"form-control\"/>\n    Duration : <input type=\"text\" name=\"cduration\" \n    [(ngModel)]=\"newCourse.duration\" class=\"form-control\"/>\n    Price : <input type=\"text\" name=\"cprice\" \n    [(ngModel)]=\"newCourse.price\" class=\"form-control\"/>\n    Rating : <input type=\"text\" name=\"crating\"\n     [(ngModel)]=\"newCourse.rating\" class=\"form-control\"/>\n    \n    <br/>\n    <input type=\"submit\" value=\"Add Course\"\n     class=\"btn btn-primary\" [disabled]=\"!f.valid\" />\n\n\n</form>\n\n\n<input type=\"text\" [(ngModel)]=\"name\" />\n\n<ul [ngSwitch]=\"name\">\n  <li *ngSwitchCase=\"'Angular'\">Angular</li>\n  <li *ngSwitchCase=\"'React'\">React</li>\n  <li *ngSwitchCase=\"'Node'\">Node</li>\n  <li *ngSwitchDefault>No course with this name</li>\n</ul>\n\n\n<div>\n\n</div>\n\n\n<div *ngFor=\"let c of courses\" [ngClass]=\"{'CourseStyle':true,'CourseBackground':true}\">\n  <course [coursedetails]=\"c\"></course>\n</div>\n\n"
    })
], ListOfCoursesComponent);
exports.ListOfCoursesComponent = ListOfCoursesComponent;
//# sourceMappingURL=listofcourses.component.js.map