"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var http_1 = require("@angular/http");
var router_1 = require("@angular/router");
var app_component_1 = require("./app.component");
var courses_component_1 = require("./courses.component");
var duration_pipe_1 = require("./duration.pipe");
var usecourseservice_1 = require("./usecourseservice");
var course_service_1 = require("./course.service");
var post_component_1 = require("./post.component");
var listofcourses_component_1 = require("./listofcourses.component");
var postdetail_component_1 = require("./postdetail.component");
var login_component_1 = require("./login.component");
var dashboard_component_1 = require("./dashboard.component");
var user_service_1 = require("./user.service");
var authgaurd_service_1 = require("./authgaurd.service");
var poststyle_directive_1 = require("./poststyle.directive");
// const routes:Routes =[
// {path:'posts',component:PostsComponent},
// {path:'courses',component:ListOfCoursesComponent},
// {path:'post/:id',component:PostDetailComponent},
// {path:'',redirectTo:'/posts',pathMatch:'full'},
// {path:'**',redirectTo:'/courses',pathMatch:'full'}
// ]
var routes = [
    {
        path: 'dashboard',
        component: dashboard_component_1.DashBoardComponent,
        children: [
            { path: '', component: post_component_1.PostsComponent },
            { path: 'courses', component: listofcourses_component_1.ListOfCoursesComponent }
        ]
        //,  canActivate:[AuthGaurd]
    },
    { path: '', component: login_component_1.LoginComponent }
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [http_1.HttpModule, platform_browser_1.BrowserModule,
            forms_1.FormsModule, router_1.RouterModule.forRoot(routes)],
        declarations: [poststyle_directive_1.PostStyleDirective, login_component_1.LoginComponent, dashboard_component_1.DashBoardComponent, postdetail_component_1.PostDetailComponent, app_component_1.AppComponent, courses_component_1.CourseComponent,
            listofcourses_component_1.ListOfCoursesComponent, duration_pipe_1.DurationPipe, post_component_1.PostsComponent, usecourseservice_1.UseCourseServComponent],
        bootstrap: [app_component_1.AppComponent],
        providers: [course_service_1.CourseService, user_service_1.UserService, authgaurd_service_1.AuthGaurd]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map