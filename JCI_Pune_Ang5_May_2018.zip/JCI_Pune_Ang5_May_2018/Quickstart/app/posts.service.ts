import {Http} from '@angular/http';
import { Injectable } from '@angular/core';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostsService{
    constructor(public httpServObj:Http){

    }

    // Using CallBack
    // getPosts(callBackFunc:any){       
    //     this.httpServObj.get('https://jsonplaceholder.typicode.com/posts').subscribe((response)=>{
    //     callBackFunc(response.json());
    //         }
    //     )
    // }

    // Using Promises !

    getPosts(){       
      return  this.httpServObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
    }
}