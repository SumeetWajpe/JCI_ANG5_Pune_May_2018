
import { Component } from "@angular/core";
import { UserService } from "./user.service";

@Component({
        selector:'dashboard',
        template:`<h1> Within Dashboard ! You are authenticated ! </h1>
       

        <router-outlet></router-outlet>

        `

})
export class DashBoardComponent{


    constructor(private servObj:UserService){

    }

}