import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { UserService } from "./user.service";
import {Injectable} from '@angular/core';

@Injectable()
export class AuthGaurd implements CanActivate{
    constructor(private route:Router,
        private userservObj:UserService){

    }

    canActivate(actRoute:ActivatedRouteSnapshot,
        state:RouterStateSnapshot):boolean{
        if(!this.userservObj.getUserLoggedIn()){
            this.route.navigate(['/']);
        }

        return this.userservObj.getUserLoggedIn();
    }
}